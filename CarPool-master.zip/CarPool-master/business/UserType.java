package business;

public enum UserType{Driver, Passenger, Both}