package business;

public enum Gender{Female ,Male, Other}